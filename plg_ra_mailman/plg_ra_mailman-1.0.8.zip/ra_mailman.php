<?php

/**
 * @package     Ramblers.Plugin
 * @subpackage  System.ra_mailman
 *
 * @copyright   (C) 2021 Clifford E Ford.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * 08/08/25 CB created
 */
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;

/**
 * This class is not used by the plugin but needs to be present to satisfy the
 * installer. Without it the plugin will not install.
 */
class Plgsystemra_mailman extends CMSPlugin {

}
